function getBaseURL(host) {
  return 'https://' + host + '.dropboxapi.com/2/';
}

module.exports = getBaseURL;
