/// <reference path="../dist/dropbox.d.ts" />

export = DropboxTypes.Dropbox;

