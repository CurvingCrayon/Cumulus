/// <reference path="../../dist/dropbox_team.d.ts" />

export = DropboxTypes.DropboxTeam;

