var REQUEST_CONSTANTS = {
  RPC: 'rpc',
  DOWNLOAD: 'download',
  UPLOAD: 'upload'
};

module.exports = REQUEST_CONSTANTS;
