# Dropbox TypeScript SDK Examples

To run the examples in your development environment:

1. Clone this repo
2. Run `npm install` in the root of the repository
3. `cd` into this directory
4. Run `npm install`
3. From this directory, start the development server with
   `npm start`
4. Point your browser to <http://0.0.0.0:8080/>
